# To Start Project
npm start
# To Make Build File
npm run build
# To Create New Migration With File Name
npm run create-migration user
# To apply Migrations
npm run apply-migration